"""Uma vista (página) por módulo; cada uma expõe render(start_time)."""
