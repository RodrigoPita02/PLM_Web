"""Lógica de aplicação sem UI."""
