"""Camada de apresentação (Streamlit)."""
