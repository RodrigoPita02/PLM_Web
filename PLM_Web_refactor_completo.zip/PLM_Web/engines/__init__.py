"""Engines de validação, organizados por app/domínio."""
