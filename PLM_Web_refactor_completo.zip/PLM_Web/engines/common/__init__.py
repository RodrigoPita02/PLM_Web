"""Infraestrutura partilhada: paths, loaders, relatórios Excel, logs de execução."""
