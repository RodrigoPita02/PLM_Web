"""App: SSA Validation."""
from engines.ssa.pipeline import run_ssa_validation

__all__ = ["run_ssa_validation"]
